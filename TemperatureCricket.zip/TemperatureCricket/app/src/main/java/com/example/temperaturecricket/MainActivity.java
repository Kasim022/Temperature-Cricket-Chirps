package com.example.temperaturecricket;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {


    Button button;
    TextView Text1;
    EditText etn;
    DecimalFormat formatter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        formatter = new DecimalFormat("#0.0");

        Text1 = findViewById(R.id.Text1);
        button = findViewById(R.id.button);
        etn = findViewById(R.id.etn);

        Text1.setVisibility(View.GONE);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (etn.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please Enter a number", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    int chrips = Integer.parseInt(etn.getText().toString().trim());

                    double temp = (chrips / 3.0) + 4;

                    String result = "The temperature is: " + formatter.format(temp) + "degree celsius";

                    Text1.setText(result);
                    Text1.setVisibility(View.VISIBLE);
                }

            }
        });

    }
}